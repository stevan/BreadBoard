package MyMooseB;

use Moose;

1;